<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            [
                'name' => 'Horror',
                'description' => 'Horror Book',
            ],
            [
                'name' => 'Thriller',
                'description' => 'Thriller Book',
            ],
            [
                'name' => 'Sci-Fi',
                'description' => 'Sci-Fi Book',
            ],
            [
                'name' => 'Romance',
                'description' => 'Romance Book',
            ],
        ]);
    }
}
