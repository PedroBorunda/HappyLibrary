<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([
            [
                'name' => 'La teoria del todo',
                'author' => 'Stephen Hawking',
                'category_id' => '3',
                'publication' => '2018/03/01',
                'user_id' => null,
                'not_available' => null,
            ],
            [
                'name' => 'El hombre en busca de sentido',
                'author' => 'Viktor Frankl',
                'category_id' => '1',
                'publication' => '2017/01/01',
                'user_id' => null,
                'not_available' => null,
            ],
        ]);
    }
}
