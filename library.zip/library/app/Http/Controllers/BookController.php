<?php

namespace App\Http\Controllers;

use App\Book;
use App\User;
use App\Category;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\Factory;
use Illuminate\Database\Eloquent\Collection;

class BookController extends Controller
{
    /**
     * @return Factory|View
     */
    public function show() {
        $categories = Category::all();
        //dd($categories);
        $params = compact('categories');
        return view('books.show', $params);
    }

    /**
     * @return Factory|View
     */
    public function create() {
        $categories = Category::all();
        $users = User::all();
        $params = compact('categories', 'users');
        return view('books.create', $params);
    }

    /**
     * @param $id
     * @return Factory|View
     */
    public function edit($id) {
        $book = Book::find($id);
        $categories = Category::all();
        $users = User::all();
        $params = compact('categories', 'users', 'book');
        return view('books.create', $params);
    }

    /**
     * @param Request $request
     * @param null $id
     * @return JsonResponse
     */
    public function setAvailability(Request $request, $id)
    {
        //dd($request->all());

        $book = Book::find($id);

        $validator = Validator::make($request->all(), [
            'availability' => 'required|in:true,false',
        ], [], []);

        if ($validator->fails())
        {
            return response()->json([
                'success' => false,
                'data' => $validator->errors()->all(),
            ]);
        }

        // recibe del front si esta disponible, si es true, not_available es null, else 1
        $book->not_available = $request->availability == 'true' ? null : 1;

        if($book->save()){
            return response()->json([
                'success' => true,
                'msg' => 'Book created successfully',
                'book' => $book,
            ]);
        }
    }


    /**
     * @param Request $request
     * @param null $id
     * @return JsonResponse
     */
    public function storeUpdate(Request $request, $id = null) {
        //dd($request->all());

        if($id)
        {
            $book = Book::find($id);

            if ($book->not_available != null && $request->user_id != null)
            {
                return response()->json([
                    'success' => false,
                    'data' => ["A user can't be assigned to a book which is \"not available \""],
                ]);
            }
        }
        else
        {
            $book = new Book();
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|max:255',
            'author' => 'required|max:255',
            'publication' => 'required|date',
            'category_id' => 'required|exists:categories,id',
            'user_id' => 'nullable|exists:users,id',
        ], [], [
            'name' => 'book name',
            'category_id' => 'category',
            'user_id' => 'user',
            'publication' => 'publish date',
        ]);


        if ($validator->fails())
        {
            return response()->json([
                'success' => false,
                'data' => $validator->errors()->all(),
            ]);
        }

        $book->name = $request->name;
        $book->author = $request->author;
        $book->publication = Carbon::parse($request->publication);
        $book->category_id = $request->category_id;
        $book->user_id = $request->user;

        if($book->save()){
            return response()->json([
                'success' => true,
                'msg' => 'Book created successfully',
                'book' => $book,
            ]);
        }
    }

    /**
     * @param $id
     * @return JsonResponse
     * @throws \Exception
     */
    public function destroy($id) {
        $book = Book::find($id);
        if($book->delete()) {
            return response()->json([
                'success' => true,
                'msg' => 'Book deleted successfully',
            ]);
        }
    }


    /**
     * @param Request $request
     * @return Book|Book[]|Collection
     */
    public function getBooks(Request $request){
        $filter = $request->filter;
        $search = $request->search;
        $books = Book::join('categories', 'categories.id', '=', 'books.category_id')
            ->leftJoin('users', 'users.id', '=', 'books.user_id');

        if($filter)
        {
            $books->where('category_id', $filter);
        }

        if($search)
        {
            $books->where('books.name', 'LIKE', "%$search%")
                ->orwhere('books.author', 'LIKE', "%$search%")
                ->orwhere('books.publication', 'LIKE', "%$search%")
                ->orwhere('users.name', 'LIKE', "%$search%")
                ->orwhere('categories.name', 'LIKE', "%$search%");
        }

        $books = $books->get([
            'books.id as id',
            'books.name as name',
            'books.author as author',
            DB::raw('DATE_FORMAT(publication, "%m/%d/%Y") as publication'),
            'categories.name as category',
            DB::raw('IF(not_available IS NULL, "available", "not available") as availability'),
            'users.name as user',
        ]);

        return $books;
    }
}

