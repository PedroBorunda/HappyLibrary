@extends('layouts.master')
@section('head')
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
@stop
@section('body')
    <div id="createBooks">

        <div class="container spacing-md">
            <div class="row">
                <div class="col-6">
                    <div class="input-group">
                        <label for="name"> Book Name
                            <input type="text" id="name" name="name" class="form-control" value="{{ $book->name ?? '' }}">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="author"> Author
                            <input type="text" id="author" name="author" class="form-control" value="{{ $book->author ?? '' }}">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="user"> User
                            <select id="user" name="user" class="form-control">
                                <option value="" selected></option>
                                @foreach($users as $user)
                                    <option value="{{$user->id}}" @if(isset($book) && $book->user_id == $user->id){{ 'selected' }}@endif>{{$user->name}}</option>
                                @endforeach
                            </select>
                        </label>
                    </div>
                </div>
                <div class="col-6">
                    <div class="input-group">
                        <label for="category"> Category
                            <select id="category" name="category" class="form-control">
                                <option value="" selected></option>
                                @foreach($categories as $category)
                                    <option value="{{$category->id}}" @if(isset($book) && $book->category_id == $category->id){{ 'selected' }}@endif >{{$category->name}}</option>
                                @endforeach
                            </select>
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="publish"> Publish Date
                            <input type="date" id="publish" name="publish" class="form-control" value="{{ $book->publication ?? '' }}">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <div class="input-group" id="button-addon">
                            <button class="btn btn-outline-secondary" type="button" id="saveBtn">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="clearfix spacing-md"></div>

        </div>
    </div>
@stop
@section('scripts')
    <script>
        let postBooks = () => {
            $.ajax({
                type: 'POST',
                url: '/books/storeUpdate/{{ $book->id ?? '' }}',
                data: {
                    name: $('#name').val(),
                    author: $('#author').val(),
                    publication: $('#publish').val(),
                    category_id: $('#category').val(),
                    user: $('#user').val(),
                },
                success: (res) => {
                    console.log(res);

                    if (res.success)
                    {
                        $.alert({
                            content: 'Success!',
                        });
                        window.location.href = '/books';
                    }
                    else
                    {
                        let errors = '';
                        res.data.forEach(function (item, i) {
                            errors += `<div>${item}</div>`;
                        });
                        $.alert({
                            title: 'error:',
                            content: errors,
                        });
                    }
                },
                error: () => {
                    $.alert({
                        content: 'error processing request',
                    });
                }
            });
        };

        $('#saveBtn').click(function () {
            postBooks();
        });
    </script>
@stop