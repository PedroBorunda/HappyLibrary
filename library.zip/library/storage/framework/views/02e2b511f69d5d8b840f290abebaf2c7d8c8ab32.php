<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div id="showBooks">

        <div class="container spacing-md">

            <div class="row">
                <div class="col-6">
                    <div class="input-group">
                        <input type="text" id="search" class="form-control">
                        <div class="input-group-append" id="button-addon4">
                            <button class="btn btn-outline-secondary" type="button" id="searchBtn">Search</button>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <select name="filter" id="filter" class="form-control">
                        <option value="" selected></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="clearfix spacing-md"></div>

            <table class="table" id="myTable">
                <thead>
                <tr>
                    <th>
                        ID
                    </th>
                    <th>
                        Name
                    </th>
                    <th>
                        Author
                    </th>
                    <th>
                        Publication
                    </th>
                    <th>
                        Category
                    </th>
                    <th>
                        Availability
                    </th>
                    <th>
                        User
                    </th>
                    <th>
                        Actions
                    </th>
                </tr>
                </th>
                </thead>
                <tbody>
                <tr>

                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="title" class="modal-title">

                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="book_id">
                    <div class="input-group-text">
                        <input id="available" type="checkbox" aria-label="Book Available"> Available
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="saveBtn" type="button" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        let getBooks = () => {
            $.ajax({
                type: 'GET',
                url: 'books/getBooks',
                data: {
                    filter: $('#filter').val(),
                    search: $('#search').val(),
                },
                success: (res) => {
                    console.log(res);

                    let table = $('#myTable'),
                        tbody = table.find('tbody');

                    tbody.html('');

                    res.forEach(function (item, i) {
                        tbody.append(
                            `<tr data-id="${item.id}" data-available="${item.availability}"  data-name="${item.name}">`+
                            `<td>${item.id}</td>`+
                            `<td>${item.name}</td>`+
                            `<td>${item.author}</td>`+
                            `<td>${item.publication}</td>`+
                            `<td>${item.category}</td>`+
                            `<td><a href="#modal" data-toggle="modal" data-target="#modal">${item.availability}</a></td>`+
                            `<td>${item.user ? item.user : ''}</td>`+
                            `<td><a href="/books/edit/${item.id}"><i class="far fa-edit"></i></a>`+
                            `<a onclick="deleteBook(${item.id})" href="#" data-id="${item.id}"><i class="far fa-trash-alt"></i></a></td></tr>`
                        )
                    });
                },
                error: () => {

                }
            });
        };


        let postBooks = ($book_id, $availability) => {
            $.ajax({
                type: 'POST',
                url: `/books/setAvailability/${$book_id}`,
                data: {
                    availability: $availability,
                },
                success: (res) => {
                    console.log(res);

                    if (res.success)
                    {
                        alert('Success!');
                        window.location.href = '/books';
                    }
                    else
                    {
                        let errors = '';
                        res.data.forEach(function (item, i) {
                            errors += `<div>${item}</div>`;
                        });
                        $.alert({
                            title: 'error:',
                            content: errors,
                        });
                    }
                },
                error: () => {
                    $.alert({
                        content: 'error processing request',
                    });
                }
            });
        };


        let deleteBook = ($id) => {
            $.ajax({
                type: 'POST',
                url: `books/delete/${$id}`,
                success: (res) => {
                    console.log(res);

                    $.alert({
                        content: 'Book deleted!',
                    });
                    getBooks();
                },
                error: () => {

                }
            });
        };

        $('#searchBtn').click(function () {
            getBooks();
        });

        $('#saveBtn').click(function () {
            postBooks($('#book_id').val(), $('#available').is(':checked'));
        });

        $('#search').on('keyup', function (e) {
            if (e.which == 13)
            {
                getBooks();
            }
        });

        $('#filter').change(function () {
            getBooks();
        });

        $('#modal').on('show.bs.modal', function (e) {
            let modal = $(this),
                invoker = $(e.relatedTarget),
                tr = invoker.closest('tr'),
                id = tr.data('id'),
                name = tr.data('name'),
                available = tr.data('available'),
                title = modal.find('#title'),
                checkbox_input = modal.find('#available'),
                id_input = modal.find('#book_id');

            title.append(name);
            id_input.val(id);
            if(available == "available")
            {
                checkbox_input.prop("checked", true);
            }

        });

        $(document).ready(function () {
            getBooks();
        });
    </script>





    <script>
        /*$(document).ready( function () {
            $('#myTable').DataTable();
        } );*/
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>