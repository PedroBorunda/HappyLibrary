<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div id="createBooks">

        <div class="container spacing-md">
            <div class="row">
                <div class="col-6">
                    <div class="input-group">
                        <label for="name"> Book Name
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($book->name ?? ''); ?>">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="author"> Author
                            <input type="text" id="author" name="author" class="form-control" value="<?php echo e($book->author ?? ''); ?>">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="user"> User
                            <select id="user" name="user" class="form-control">
                                <option value="" selected></option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php if(isset($book) && $book->user_id == $user->id): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                </div>
                <div class="col-6">
                    <div class="input-group">
                        <label for="category"> Category
                            <select id="category" name="category" class="form-control">
                                <option value="" selected></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if(isset($book) && $book->category_id == $category->id): ?><?php echo e('selected'); ?><?php endif; ?> ><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <label for="publish"> Publish Date
                            <input type="date" id="publish" name="publish" class="form-control" value="<?php echo e($book->publication ?? ''); ?>">
                        </label>
                        <div class="clearfix spacing-sm"></div>
                        <div class="input-group" id="button-addon">
                            <button class="btn btn-outline-secondary" type="button" id="saveBtn">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="clearfix spacing-md"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let postBooks = () => {
            $.ajax({
                type: 'POST',
                url: '/books/storeUpdate/<?php echo e($book->id ?? ''); ?>',
                data: {
                    name: $('#name').val(),
                    author: $('#author').val(),
                    publication: $('#publish').val(),
                    category_id: $('#category').val(),
                    user: $('#user').val(),
                },
                success: (res) => {
                    console.log(res);

                    if (res.success)
                    {
                        $.alert({
                            content: 'Success!',
                        });
                        window.location.href = '/books';
                    }
                    else
                    {
                        let errors = '';
                        res.data.forEach(function (item, i) {
                            errors += `<div>${item}</div>`;
                        });
                        $.alert({
                            title: 'error:',
                            content: errors,
                        });
                    }
                },
                error: () => {
                    $.alert({
                        content: 'error processing request',
                    });
                }
            });
        };

        $('#saveBtn').click(function () {
            postBooks();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>